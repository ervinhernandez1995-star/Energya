import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  BarChart3, 
  TrendingUp, 
  DollarSign, 
  ShoppingCart, 
  Users, 
  Package,
  Calendar,
  Download,
  Filter,
  Eye
} from 'lucide-react'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js'
import { Line, Bar, Doughnut, Radar } from 'react-chartjs-2'

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
)

const Analytics: React.FC = () => {
  const [timeRange, setTimeRange] = useState('7d')
  const [selectedMetric, setSelectedMetric] = useState('revenue')

  // Datos para diferentes períodos
  const periodData = {
    '7d': {
      revenue: [1200, 1900, 2100, 1800, 2400, 2800, 3200],
      orders: [12, 19, 21, 18, 24, 28, 32],
      visitors: [180, 240, 210, 190, 260, 290, 340],
    },
    '30d': {
      revenue: [2800, 3200, 2900, 3600, 4100, 3800, 4500, 4200, 4800, 5100],
      orders: [28, 32, 29, 36, 41, 38, 45, 42, 48, 51],
      visitors: [420, 450, 410, 480, 520, 490, 560, 540, 580, 620],
    },
    '90d': {
      revenue: [3200, 3600, 4100, 4800, 5200, 5800, 6200, 6800, 7200, 7800, 8200, 8800],
      orders: [32, 36, 41, 48, 52, 58, 62, 68, 72, 78, 82, 88],
      visitors: [580, 620, 680, 720, 760, 820, 860, 920, 960, 1020, 1060, 1120],
    }
  }

  const currentData = periodData[timeRange as keyof typeof periodData]

  // Gráfico de Ingresos
  const revenueData = {
    labels: timeRange === '7d' ? ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'] :
            timeRange === '30d' ? Array.from({length: 10}, (_, i) => `Día ${i + 1}`) :
            Array.from({length: 12}, (_, i) => `Mes ${i + 1}`),
    datasets: [
      {
        label: 'Ingresos ($)',
        data: currentData.revenue,
        borderColor: 'rgb(37, 99, 235)',
        backgroundColor: 'rgba(37, 99, 235, 0.1)',
        tension: 0.4,
        fill: true,
      },
    ],
  }

  // Gráfico de Órdenes
  const ordersData = {
    labels: timeRange === '7d' ? ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'] :
            timeRange === '30d' ? Array.from({length: 10}, (_, i) => `Día ${i + 1}`) :
            Array.from({length: 12}, (_, i) => `Mes ${i + 1}`),
    datasets: [
      {
        label: 'Órdenes',
        data: currentData.orders,
        backgroundColor: 'rgba(22, 163, 74, 0.8)',
        borderColor: 'rgb(22, 163, 74)',
        borderWidth: 1,
      },
    ],
  }

  // Gráfico de Categorías
  const categoryData = {
    labels: ['Electrónicos', 'Ropa', 'Hogar', 'Deportes', 'Belleza', 'Mascotas'],
    datasets: [
      {
        data: [35, 25, 18, 12, 7, 3],
        backgroundColor: [
          '#2563eb',
          '#16a34a',
          '#f59e0b',
          '#dc2626',
          '#8b5cf6',
          '#06b6d4',
        ],
        borderWidth: 0,
      },
    ],
  }

  // Análisis de Rendimiento por Producto
  const productPerformanceData = {
    labels: ['iPhone 15', 'Nike Shoes', 'MacBook', 'Sony Audio', 'Smart Watch', 'Overshirt'],
    datasets: [
      {
        label: 'Ventas ($)',
        data: [2400, 1800, 3200, 1600, 1400, 900],
        backgroundColor: 'rgba(37, 99, 235, 0.8)',
      },
      {
        label: 'Ganancia ($)',
        data: [600, 450, 800, 400, 350, 225],
        backgroundColor: 'rgba(22, 163, 74, 0.8)',
      },
    ],
  }

  // Datos de funnel de conversión
  const funnelData = {
    labels: ['Visitantes', 'Producto Visto', 'Añadido al Carrito', 'Checkout', 'Compra Completada'],
    datasets: [
      {
        label: 'Conversiones',
        data: [100, 65, 45, 32, 28],
        backgroundColor: [
          'rgba(37, 99, 235, 0.8)',
          'rgba(59, 130, 246, 0.8)',
          'rgba(96, 165, 250, 0.8)',
          'rgba(147, 197, 253, 0.8)',
          'rgba(22, 163, 74, 0.8)',
        ],
      },
    ],
  }

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
    },
  }

  const metrics = [
    {
      title: 'INGRESOS TOTALES',
      value: '$47,847',
      change: '+18.2%',
      trend: 'up',
      icon: DollarSign,
      color: 'text-success',
    },
    {
      title: 'ÓRDENES TOTALES',
      value: '847',
      change: '+12.5%',
      trend: 'up',
      icon: ShoppingCart,
      color: 'text-primary-600',
    },
    {
      title: 'TASA DE CONVERSIÓN',
      value: '3.2%',
      change: '+0.8%',
      trend: 'up',
      icon: TrendingUp,
      color: 'text-warning',
    },
    {
      title: 'VISITANTES ÚNICOS',
      value: '12,847',
      change: '-2.1%',
      trend: 'down',
      icon: Users,
      color: 'text-error',
    },
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-text-primary">Analytics Avanzados</h1>
          <p className="text-text-secondary mt-2">
            Métricas detalladas y análisis de rendimiento para optimizar tu negocio
          </p>
        </div>
        <div className="flex gap-3 mt-4 lg:mt-0">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="input-field"
          >
            <option value="7d">Últimos 7 días</option>
            <option value="30d">Últimos 30 días</option>
            <option value="90d">Últimos 90 días</option>
          </select>
          <button className="btn-secondary">
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </button>
        </div>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => {
          const Icon = metric.icon
          return (
            <motion.div
              key={metric.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="kpi-card"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-text-secondary uppercase">
                    {metric.title}
                  </p>
                  <p className="text-3xl font-bold text-text-primary mt-2">
                    {metric.value}
                  </p>
                  <div className="flex items-center mt-2">
                    <span className={`text-sm font-medium ${
                      metric.trend === 'up' ? 'text-success' : 'text-error'
                    }`}>
                      {metric.change}
                    </span>
                    <span className="text-sm text-text-secondary ml-2">
                      vs período anterior
                    </span>
                  </div>
                </div>
                <Icon className={`h-8 w-8 ${metric.color}`} />
              </div>
            </motion.div>
          )
        })}
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="card"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-text-primary">
              Ingresos por Período
            </h3>
            <BarChart3 className="h-5 w-5 text-text-secondary" />
          </div>
          <div className="h-80">
            <Line data={revenueData} options={chartOptions} />
          </div>
        </motion.div>

        {/* Orders Chart */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="card"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-text-primary">
              Órdenes por Período
            </h3>
            <ShoppingCart className="h-5 w-5 text-text-secondary" />
          </div>
          <div className="h-80">
            <Bar data={ordersData} options={chartOptions} />
          </div>
        </motion.div>
      </div>

      {/* Second Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Category Performance */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="card"
        >
          <h3 className="text-lg font-semibold text-text-primary mb-4">
            Ventas por Categoría
          </h3>
          <div className="h-64">
            <Doughnut 
              data={categoryData} 
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    position: 'bottom' as const,
                  },
                },
              }} 
            />
          </div>
        </motion.div>

        {/* Product Performance */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="lg:col-span-2 card"
        >
          <h3 className="text-lg font-semibold text-text-primary mb-4">
            Rendimiento por Producto
          </h3>
          <div className="h-64">
            <Bar data={productPerformanceData} options={chartOptions} />
          </div>
        </motion.div>
      </div>

      {/* Third Row - Funnel and Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Conversion Funnel */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="card"
        >
          <h3 className="text-lg font-semibold text-text-primary mb-4">
            Funnel de Conversión
          </h3>
          <div className="h-80">
            <Bar 
              data={funnelData} 
              options={{
                ...chartOptions,
                indexAxis: 'y' as const,
                scales: {
                  x: {
                    beginAtZero: true,
                    max: 100,
                  },
                },
              }} 
            />
          </div>
        </motion.div>

        {/* Key Insights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="card"
        >
          <h3 className="text-lg font-semibold text-text-primary mb-4">
            Insights Clave
          </h3>
          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <TrendingUp className="h-5 w-5 text-success mt-1" />
              <div>
                <p className="font-medium text-text-primary">
                  Crecimiento de Ingresos
                </p>
                <p className="text-sm text-text-secondary">
                  Los ingresos han crecido 18.2% en el último mes
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <Package className="h-5 w-5 text-primary-500 mt-1" />
              <div>
                <p className="font-medium text-text-primary">
                  Producto Estrella
                </p>
                <p className="text-sm text-text-secondary">
                  iPhone 15 genera el 28% de las ventas totales
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <Eye className="h-5 w-5 text-warning mt-1" />
              <div>
                <p className="font-medium text-text-primary">
                  Optimización de Conversión
                </p>
                <p className="text-sm text-text-secondary">
                  45% añade al carrito pero solo 62% completa compra
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <Calendar className="h-5 w-5 text-error mt-1" />
              <div>
                <p className="font-medium text-text-primary">
                  Mejores Días
                </p>
                <p className="text-sm text-text-secondary">
                  Sábado y domingo generan 40% más ventas que días laborables
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}

export default Analytics