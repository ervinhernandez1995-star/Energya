import React from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { 
  Star, 
  ShoppingCart, 
  TrendingUp, 
  Eye, 
  Heart,
  Package,
  Shield,
  Truck,
  CreditCard,
  Zap,
  BarChart3
} from 'lucide-react'

interface FeaturedProduct {
  id: string
  title: string
  price: number
  originalPrice: number
  image: string
  rating: number
  reviews: number
  badge?: string
  category: string
}

const Home: React.FC = () => {
  const featuredProducts: FeaturedProduct[] = [
    {
      id: '1',
      title: 'iPhone 15 Pro Max 256GB',
      price: 899,
      originalPrice: 1199,
      image: 'https://via.placeholder.com/400x400/2563eb/white?text=iPhone+15',
      rating: 4.9,
      reviews: 1247,
      badge: 'Best Seller',
      category: 'Electrónicos'
    },
    {
      id: '2',
      title: 'Zapatillas Nike Air Max',
      price: 89,
      originalPrice: 149,
      image: 'https://via.placeholder.com/400x400/16a34a/white?text=Nike',
      rating: 4.7,
      reviews: 892,
      badge: 'Trending',
      category: 'Ropa'
    },
    {
      id: '3',
      title: 'MacBook Air M2 13"',
      price: 899,
      originalPrice: 1299,
      image: 'https://via.placeholder.com/400x400/6b7280/white?text=MacBook',
      rating: 4.8,
      reviews: 567,
      badge: 'Premium',
      category: 'Electrónicos'
    },
    {
      id: '4',
      title: 'Smartwatch Apple Watch',
      price: 299,
      originalPrice: 429,
      image: 'https://via.placeholder.com/400x400/f59e0b/white?text=Apple+Watch',
      rating: 4.6,
      reviews: 734,
      badge: 'New',
      category: 'Electrónicos'
    }
  ]

  const categories = [
    { name: 'Electrónicos', count: 45, icon: '📱' },
    { name: 'Ropa', count: 38, icon: '👕' },
    { name: 'Hogar', count: 32, icon: '🏠' },
    { name: 'Deportes', count: 24, icon: '⚽' },
    { name: 'Belleza', count: 18, icon: '💄' },
  ]

  const features = [
    {
      icon: Shield,
      title: 'Compra Segura',
      description: 'Protección al consumidor con garantía de satisfacción'
    },
    {
      icon: Truck,
      title: 'Envío Rápido',
      description: 'Entregas en 24-48 horas a toda la península'
    },
    {
      icon: Zap,
      title: 'Envío Automático',
      description: 'Gestión automatizada desde proveedores verificados'
    },
    {
      icon: BarChart3,
      title: 'Precios Competitivos',
      description: 'Mejores precios del mercado sin comprometer calidad'
    }
  ]

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center py-12 px-4"
      >
        <h1 className="text-4xl md:text-6xl font-bold text-text-primary mb-4">
          Tu Tienda de 
          <span className="text-primary-500"> Dropshipping </span>
          Automatizada
        </h1>
        <p className="text-xl text-text-secondary mb-8 max-w-3xl mx-auto">
          Productos seleccionados por IA, precios competitivos y envío automático. 
          Tu e-commerce optimizado para máxima ganancia.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/products" className="btn-primary text-lg px-8 py-4">
            <ShoppingCart className="h-5 w-5 mr-2" />
            Ver Productos
          </Link>
          <Link to="/dashboard" className="btn-secondary text-lg px-8 py-4">
            <BarChart3 className="h-5 w-5 mr-2" />
            Dashboard
          </Link>
        </div>
      </motion.section>

      {/* Stats Section */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="card"
      >
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div>
            <p className="text-2xl font-bold text-primary-500">156</p>
            <p className="text-text-secondary">Productos Activos</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-success">2,847</p>
            <p className="text-text-secondary">Ganancias Este Mes</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-warning">98%</p>
            <p className="text-text-secondary">Satisfacción Cliente</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-text-primary">24/7</p>
            <p className="text-text-secondary">Servicio Automatizado</p>
          </div>
        </div>
      </motion.section>

      {/* Categories */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <h2 className="text-2xl font-bold text-text-primary mb-6">Categorías Populares</h2>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {categories.map((category, index) => (
            <motion.div
              key={category.name}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 * index }}
              className="card text-center cursor-pointer hover:scale-105 transition-transform"
            >
              <div className="text-3xl mb-2">{category.icon}</div>
              <h3 className="font-semibold text-text-primary">{category.name}</h3>
              <p className="text-sm text-text-secondary">{category.count} productos</p>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* Featured Products */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-text-primary">Productos Destacados</h2>
          <Link to="/products" className="text-primary-500 hover:text-primary-600 font-medium">
            Ver todos →
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * index }}
              className="card group"
            >
              {/* Product Image */}
              <div className="relative overflow-hidden rounded-button mb-4">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                {product.badge && (
                  <div className="absolute top-2 left-2 bg-primary-500 text-white px-2 py-1 rounded-full text-xs font-medium">
                    {product.badge}
                  </div>
                )}
                <div className="absolute top-2 right-2 space-y-2">
                  <button className="p-2 bg-white/90 backdrop-blur-sm rounded-full hover:bg-white transition-colors">
                    <Heart className="h-4 w-4" />
                  </button>
                  <button className="p-2 bg-white/90 backdrop-blur-sm rounded-full hover:bg-white transition-colors">
                    <Eye className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {/* Product Info */}
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-text-secondary mb-1">{product.category}</p>
                  <h3 className="font-semibold text-text-primary line-clamp-2">
                    {product.title}
                  </h3>
                  <div className="flex items-center mt-1">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <span className="text-sm text-text-secondary ml-1">
                        {product.rating} ({product.reviews})
                      </span>
                    </div>
                  </div>
                </div>

                {/* Pricing */}
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-lg font-bold text-text-primary">
                      ${product.price}
                    </span>
                    <span className="text-sm text-text-secondary line-through ml-2">
                      ${product.originalPrice}
                    </span>
                  </div>
                  <span className="text-xs bg-success/10 text-success px-2 py-1 rounded-full">
                    -{Math.round((1 - product.price / product.originalPrice) * 100)}%
                  </span>
                </div>

                {/* Actions */}
                <button className="btn-primary w-full">
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Añadir al Carrito
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* Features */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <h2 className="text-2xl font-bold text-text-primary text-center mb-8">
          ¿Por qué elegir nuestra plataforma?
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
                className="text-center"
              >
                <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon className="h-8 w-8 text-primary-500" />
                </div>
                <h3 className="font-semibold text-text-primary mb-2">{feature.title}</h3>
                <p className="text-sm text-text-secondary">{feature.description}</p>
              </motion.div>
            )
          })}
        </div>
      </motion.section>

      {/* CTA Section */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="card bg-gradient-to-r from-primary-500 to-primary-600 text-white text-center py-12"
      >
        <h2 className="text-3xl font-bold mb-4">
          ¿Listo para empezar a ganar dinero?
        </h2>
        <p className="text-lg mb-6 text-primary-100">
          Únete a miles de emprendedores que ya están generando ingresos pasivos
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/analysis" className="bg-white text-primary-600 px-8 py-4 rounded-button font-semibold hover:bg-gray-100 transition-colors">
            <TrendingUp className="h-5 w-5 mr-2 inline" />
            Analizar Productos
          </Link>
          <Link to="/dashboard" className="border-2 border-white text-white px-8 py-4 rounded-button font-semibold hover:bg-white hover:text-primary-600 transition-colors">
            Ver Dashboard
          </Link>
        </div>
      </motion.section>
    </div>
  )
}

export default Home