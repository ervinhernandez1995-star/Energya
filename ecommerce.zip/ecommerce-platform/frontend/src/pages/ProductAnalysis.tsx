import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Brain, 
  TrendingUp, 
  Search, 
  BarChart3, 
  Star, 
  DollarSign,
  Target,
  AlertTriangle,
  CheckCircle,
  Download,
  RefreshCw
} from 'lucide-react'

interface AnalysisResult {
  id: string
  productTitle: string
  supplier: string
  score: number
  demand: number
  competition: number
  margin: number
  price: number
  profit: number
  recommendation: 'hot' | 'warm' | 'cold'
  insights: string[]
  trends: {
    google: number
    amazon: number
    social: number
  }
  category: string
}

const ProductAnalysis: React.FC = () => {
  const [urlInput, setUrlInput] = useState('')
  const [analysisType, setAnalysisType] = useState('single')
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  // Resultados simulados de análisis
  const analysisResults: AnalysisResult[] = [
    {
      id: '1',
      productTitle: 'Smartphone Samsung Galaxy S24 Ultra',
      supplier: 'Amazon',
      score: 94,
      demand: 92,
      competition: 78,
      margin: 23,
      price: 899,
      profit: 207,
      recommendation: 'hot',
      insights: [
        'Alta demanda en búsquedas (12,400/mes)',
        'Baja competencia en nicho premium',
        'Tendencia creciente en redes sociales',
        'Excelente margen de ganancia',
        'Calificación de productos similares: 4.7/5'
      ],
      trends: {
        google: 88,
        amazon: 94,
        social: 76
      },
      category: 'Electrónicos'
    },
    {
      id: '2',
      productTitle: 'Zapatillas deportivas Adidas Ultraboost',
      supplier: 'AliExpress',
      score: 87,
      demand: 85,
      competition: 89,
      margin: 35,
      price: 79,
      profit: 28,
      recommendation: 'warm',
      insights: [
        'Demanda moderada pero estable',
        'Competencia alta en mercado',
        'Buen margen de ganancia',
        'Popular en audiencia joven',
        'Estacional: picos en enero y junio'
      ],
      trends: {
        google: 82,
        amazon: 87,
        social: 91
      },
      category: 'Ropa'
    },
    {
      id: '3',
      productTitle: 'Kit de herramientas para hogar',
      supplier: 'Mercado Libre',
      score: 76,
      demand: 68,
      competition: 85,
      margin: 28,
      price: 45,
      profit: 13,
      recommendation: 'warm',
      insights: [
        'Demanda moderada',
        'Competencia moderada-alta',
        'Buena oferta en temporada primavera',
        'Audiencia específica: propietarios casa',
        'Productos relacionados tienen buen rendimiento'
      ],
      trends: {
        google: 73,
        amazon: 76,
        social: 68
      },
      category: 'Hogar'
    }
  ]

  const handleAnalyze = () => {
    setIsAnalyzing(true)
    // Simular análisis
    setTimeout(() => {
      setIsAnalyzing(false)
    }, 3000)
  }

  const getRecommendationColor = (recommendation: string) => {
    switch (recommendation) {
      case 'hot': return 'text-success bg-success/10'
      case 'warm': return 'text-warning bg-warning/10'
      case 'cold': return 'text-error bg-error/10'
      default: return 'text-text-secondary bg-gray-100'
    }
  }

  const getRecommendationIcon = (recommendation: string) => {
    switch (recommendation) {
      case 'hot': return <TrendingUp className="h-4 w-4" />
      case 'warm': return <Target className="h-4 w-4" />
      case 'cold': return <AlertTriangle className="h-4 w-4" />
      default: return null
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-text-primary">Análisis de Productos con IA</h1>
        <p className="text-text-secondary mt-2">
          Analiza productos automáticamente usando inteligencia artificial para maximizar ganancias
        </p>
      </div>

      {/* Analysis Input */}
      <div className="card">
        <div className="space-y-4">
          <div className="flex items-center space-x-2 mb-4">
            <Brain className="h-6 w-6 text-primary-500" />
            <h3 className="text-lg font-semibold text-text-primary">
              Nuevo Análisis
            </h3>
          </div>

          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-5 w-5 text-text-secondary" />
                <input
                  type="text"
                  placeholder="Pega la URL del producto (Amazon, AliExpress, Mercado Libre, etc.)"
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  className="input-field pl-10"
                />
              </div>
            </div>

            <select
              value={analysisType}
              onChange={(e) => setAnalysisType(e.target.value)}
              className="input-field lg:w-48"
            >
              <option value="single">Producto Único</option>
              <option value="bulk">Análisis en Lote</option>
              <option value="trending">Trending Products</option>
            </select>

            <button
              onClick={handleAnalyze}
              disabled={!urlInput || isAnalyzing}
              className="btn-primary whitespace-nowrap"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Analizando...
                </>
              ) : (
                <>
                  <Brain className="h-4 w-4 mr-2" />
                  Analizar
                </>
              )}
            </button>
          </div>

          {isAnalyzing && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="bg-primary-50 border border-primary-200 rounded-button p-4"
            >
              <div className="flex items-center space-x-3">
                <RefreshCw className="h-5 w-5 text-primary-500 animate-spin" />
                <div>
                  <p className="font-medium text-text-primary">Analizando producto...</p>
                  <p className="text-sm text-text-secondary">
                    Procesando datos de demanda, competencia y tendencias
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </div>

      {/* Analysis Results */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-text-primary">
            Resultados de Análisis
          </h2>
          <button className="btn-secondary">
            <Download className="h-4 w-4 mr-2" />
            Exportar Resultados
          </button>
        </div>

        {analysisResults.map((result, index) => (
          <motion.div
            key={result.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="card"
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-text-primary mb-2">
                  {result.productTitle}
                </h3>
                <div className="flex items-center space-x-4 text-sm text-text-secondary">
                  <span>Proveedor: {result.supplier}</span>
                  <span>Categoría: {result.category}</span>
                </div>
              </div>
              <div className="text-right">
                <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getRecommendationColor(result.recommendation)}`}>
                  {getRecommendationIcon(result.recommendation)}
                  <span className="ml-2 capitalize">{result.recommendation}</span>
                </div>
                <div className="mt-2">
                  <span className="text-2xl font-bold text-text-primary">
                    {result.score}
                  </span>
                  <span className="text-sm text-text-secondary">/100</span>
                </div>
              </div>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <div className="text-center p-3 bg-primary-50 rounded-button">
                <BarChart3 className="h-5 w-5 text-primary-500 mx-auto mb-1" />
                <p className="text-xs text-text-secondary">Demanda</p>
                <p className="text-lg font-bold text-text-primary">{result.demand}%</p>
              </div>
              <div className="text-center p-3 bg-warning/10 rounded-button">
                <Target className="h-5 w-5 text-warning mx-auto mb-1" />
                <p className="text-xs text-text-secondary">Competencia</p>
                <p className="text-lg font-bold text-text-primary">{result.competition}%</p>
              </div>
              <div className="text-center p-3 bg-success/10 rounded-button">
                <DollarSign className="h-5 w-5 text-success mx-auto mb-1" />
                <p className="text-xs text-text-secondary">Margen</p>
                <p className="text-lg font-bold text-text-primary">{result.margin}%</p>
              </div>
              <div className="text-center p-3 bg-primary-50 rounded-button">
                <TrendingUp className="h-5 w-5 text-primary-500 mx-auto mb-1" />
                <p className="text-xs text-text-secondary">Ganancia</p>
                <p className="text-lg font-bold text-text-primary">${result.profit}</p>
              </div>
            </div>

            {/* Trends */}
            <div className="mb-6">
              <h4 className="font-medium text-text-primary mb-3">Análisis de Tendencias</h4>
              <div className="grid grid-cols-3 gap-4">
                <div className="flex items-center space-x-2">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-primary-500 h-2 rounded-full" 
                      style={{ width: `${result.trends.google}%` }}
                    ></div>
                  </div>
                  <span className="text-xs text-text-secondary whitespace-nowrap">
                    Google: {result.trends.google}%
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-success h-2 rounded-full" 
                      style={{ width: `${result.trends.amazon}%` }}
                    ></div>
                  </div>
                  <span className="text-xs text-text-secondary whitespace-nowrap">
                    Amazon: {result.trends.amazon}%
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-warning h-2 rounded-full" 
                      style={{ width: `${result.trends.social}%` }}
                    ></div>
                  </div>
                  <span className="text-xs text-text-secondary whitespace-nowrap">
                    Social: {result.trends.social}%
                  </span>
                </div>
              </div>
            </div>

            {/* Insights */}
            <div>
              <h4 className="font-medium text-text-primary mb-3">Insights de IA</h4>
              <div className="space-y-2">
                {result.insights.map((insight, idx) => (
                  <div key={idx} className="flex items-start space-x-2">
                    <CheckCircle className="h-4 w-4 text-success mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-text-secondary">{insight}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 mt-6 pt-4 border-t border-border">
              <button className="btn-primary">
                <DollarSign className="h-4 w-4 mr-2" />
                Calcular Precio Final
              </button>
              <button className="btn-secondary">
                <Star className="h-4 w-4 mr-2" />
                Ver Detalles
              </button>
              <button className="btn-secondary">
                <TrendingUp className="h-4 w-4 mr-2" />
                Crear Campaña
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

export default ProductAnalysis