import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Settings as SettingsIcon, 
  User, 
  CreditCard, 
  Bell, 
  Shield, 
  Globe,
  Key,
  Save,
  Eye,
  EyeOff,
  Check,
  AlertCircle
} from 'lucide-react'

const Settings: React.FC = () => {
  const [activeTab, setActiveTab] = useState('profile')
  const [showApiKeys, setShowApiKeys] = useState(false)
  const [saved, setSaved] = useState(false)

  const handleSave = () => {
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  const tabs = [
    { id: 'profile', label: 'Perfil', icon: User },
    { id: 'payment', label: 'Pagos', icon: CreditCard },
    { id: 'notifications', label: 'Notificaciones', icon: Bell },
    { id: 'security', label: 'Seguridad', icon: Shield },
    { id: 'integrations', label: 'Integraciones', icon: Key },
    { id: 'general', label: 'General', icon: Globe },
  ]

  const settings = {
    profile: {
      businessName: 'Mi Tienda Dropshipping',
      email: 'admin@midropshop.com',
      phone: '+34 600 123 456',
      address: 'Calle Principal 123, Madrid, España',
      timezone: 'Europe/Madrid',
      currency: 'EUR'
    },
    payment: {
      paypal: 'connected',
      stripe: 'connected',
      bankAccount: '****1234',
      margin: 25,
      autoPayout: true,
      payoutFrequency: 'weekly'
    },
    notifications: {
      newOrder: true,
      lowStock: true,
      marketingReport: false,
      systemAlerts: true,
      email: true,
      push: true,
      sms: false
    },
    security: {
      twoFactorAuth: false,
      loginNotifications: true,
      ipWhitelist: false,
      sessionTimeout: 30
    },
    integrations: {
      googleTrends: 'configured',
      mailchimp: 'configured',
      socialMedia: 'configured',
      analytics: 'configured'
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-text-primary">Configuración</h1>
        <p className="text-text-secondary mt-2">
          Gestiona la configuración de tu plataforma e-commerce
        </p>
      </div>

      {/* Tabs */}
      <div className="card">
        <div className="flex space-x-1 bg-page-bg p-1 rounded-button overflow-x-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center px-4 py-2 rounded-button text-sm font-medium whitespace-nowrap transition-all ${
                  activeTab === tab.id
                    ? 'bg-white text-primary-600 shadow-sm'
                    : 'text-text-secondary hover:text-text-primary'
                }`}
              >
                <Icon className="h-4 w-4 mr-2" />
                {tab.label}
              </button>
            )
          })}
        </div>
      </div>

      {/* Tab Content */}
      <motion.div
        key={activeTab}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="card"
      >
        {activeTab === 'profile' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-text-primary">Información del Negocio</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Nombre del Negocio
                </label>
                <input
                  type="text"
                  defaultValue={settings.profile.businessName}
                  className="input-field"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Email
                </label>
                <input
                  type="email"
                  defaultValue={settings.profile.email}
                  className="input-field"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Teléfono
                </label>
                <input
                  type="tel"
                  defaultValue={settings.profile.phone}
                  className="input-field"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Zona Horaria
                </label>
                <select defaultValue={settings.profile.timezone} className="input-field">
                  <option value="Europe/Madrid">Europa/Madrid</option>
                  <option value="America/New_York">América/Nueva_York</option>
                  <option value="Asia/Tokyo">Asia/Tokio</option>
                  <option value="UTC">UTC</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Dirección
              </label>
              <textarea
                defaultValue={settings.profile.address}
                rows={3}
                className="input-field"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Moneda
              </label>
              <select defaultValue={settings.profile.currency} className="input-field">
                <option value="EUR">Euro (€)</option>
                <option value="USD">Dólar ($)</option>
                <option value="GBP">Libra (£)</option>
                <option value="CAD">Dólar Canadiense ($)</option>
              </select>
            </div>
          </div>
        )}

        {activeTab === 'payment' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-text-primary">Configuración de Pagos</h3>
            
            {/* Payment Methods */}
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border border-border rounded-button">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <CreditCard className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium text-text-primary">PayPal</p>
                    <p className="text-sm text-text-secondary">pagos@midropshop.com</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-success" />
                  <span className="text-sm text-success">Conectado</span>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border border-border rounded-button">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                    <CreditCard className="h-5 w-5 text-purple-600" />
                  </div>
                  <div>
                    <p className="font-medium text-text-primary">Stripe</p>
                    <p className="text-sm text-text-secondary">••••1234</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-success" />
                  <span className="text-sm text-success">Conectado</span>
                </div>
              </div>
            </div>

            {/* Margin Settings */}
            <div className="space-y-4">
              <h4 className="font-medium text-text-primary">Configuración de Márgenes</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">
                    Margen por Defecto (%)
                  </label>
                  <input
                    type="number"
                    defaultValue={settings.payment.margin}
                    className="input-field"
                    min="0"
                    max="100"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">
                    Frecuencia de Payout
                  </label>
                  <select defaultValue={settings.payment.payoutFrequency} className="input-field">
                    <option value="daily">Diario</option>
                    <option value="weekly">Semanal</option>
                    <option value="monthly">Mensual</option>
                  </select>
                </div>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="autoPayout"
                    defaultChecked={settings.payment.autoPayout}
                    className="mr-2"
                  />
                  <label htmlFor="autoPayout" className="text-sm font-medium text-text-primary">
                    Payout Automático
                  </label>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'integrations' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-text-primary">Integraciones de APIs</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border border-border rounded-button">
                <div>
                  <p className="font-medium text-text-primary">Google Trends API</p>
                  <p className="text-sm text-text-secondary">Para análisis de tendencias</p>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-success" />
                  <span className="text-sm text-success">Configurado</span>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border border-border rounded-button">
                <div>
                  <p className="font-medium text-text-primary">OpenAI API</p>
                  <p className="text-sm text-text-secondary">Para generación de contenido</p>
                </div>
                <button className="btn-secondary">Configurar</button>
              </div>

              <div className="flex items-center justify-between p-4 border border-border rounded-button">
                <div>
                  <p className="font-medium text-text-primary">Mailchimp API</p>
                  <p className="text-sm text-text-secondary">Para email marketing</p>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-success" />
                  <span className="text-sm text-success">Configurado</span>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border border-border rounded-button">
                <div>
                  <p className="font-medium text-text-primary">APIs de Proveedores</p>
                  <p className="text-sm text-text-secondary">Amazon, AliExpress, MercadoLibre</p>
                </div>
                <button className="btn-secondary">Configurar</button>
              </div>
            </div>

            {/* API Keys */}
            <div className="space-y-4">
              <h4 className="font-medium text-text-primary">Claves API</h4>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">
                    OpenAI API Key
                  </label>
                  <div className="flex">
                    <input
                      type={showApiKeys ? "text" : "password"}
                      placeholder="sk-..."
                      className="input-field rounded-r-none"
                    />
                    <button
                      onClick={() => setShowApiKeys(!showApiKeys)}
                      className="btn-secondary rounded-l-none px-3"
                    >
                      {showApiKeys ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">
                    PayPal Client ID
                  </label>
                  <input
                    type="password"
                    placeholder="Tu Client ID de PayPal"
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">
                    Stripe Secret Key
                  </label>
                  <input
                    type="password"
                    placeholder="sk_live_..."
                    className="input-field"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'notifications' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-text-primary">Configuración de Notificaciones</h3>
            
            <div className="space-y-4">
              {Object.entries(settings.notifications).map(([key, value]) => (
                <div key={key} className="flex items-center justify-between p-4 border border-border rounded-button">
                  <div>
                    <p className="font-medium text-text-primary">
                      {key === 'newOrder' && 'Nueva Orden'}
                      {key === 'lowStock' && 'Stock Bajo'}
                      {key === 'marketingReport' && 'Reporte de Marketing'}
                      {key === 'systemAlerts' && 'Alertas del Sistema'}
                      {key === 'email' && 'Notificaciones por Email'}
                      {key === 'push' && 'Notificaciones Push'}
                      {key === 'sms' && 'Notificaciones SMS'}
                    </p>
                  </div>
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      defaultChecked={value}
                      className="toggle-toggle"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'security' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-text-primary">Configuración de Seguridad</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border border-border rounded-button">
                <div>
                  <p className="font-medium text-text-primary">Autenticación de Dos Factores</p>
                  <p className="text-sm text-text-secondary">Añade una capa extra de seguridad</p>
                </div>
                <button className="btn-secondary">Activar</button>
              </div>

              <div className="flex items-center justify-between p-4 border border-border rounded-button">
                <div>
                  <p className="font-medium text-text-primary">Notificaciones de Login</p>
                  <p className="text-sm text-text-secondary">Recibe alertas de nuevos accesos</p>
                </div>
                <input
                  type="checkbox"
                  defaultChecked={settings.security.loginNotifications}
                  className="toggle-toggle"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Timeout de Sesión (minutos)
                </label>
                <select defaultValue={settings.security.sessionTimeout} className="input-field">
                  <option value="15">15 minutos</option>
                  <option value="30">30 minutos</option>
                  <option value="60">1 hora</option>
                  <option value="120">2 horas</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'general' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-text-primary">Configuración General</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border border-border rounded-button">
                <div>
                  <p className="font-medium text-text-primary">Modo Mantenimiento</p>
                  <p className="text-sm text-text-secondary">Desactiva la tienda temporalmente</p>
                </div>
                <input type="checkbox" className="toggle-toggle" />
              </div>

              <div className="flex items-center justify-between p-4 border border-border rounded-button">
                <div>
                  <p className="font-medium text-text-primary">Productos Destacados</p>
                  <p className="text-sm text-text-secondary">Mostrar productos destacados en la home</p>
                </div>
                <input type="checkbox" defaultChecked className="toggle-toggle" />
              </div>

              <div className="flex items-center justify-between p-4 border border-border rounded-button">
                <div>
                  <p className="font-medium text-text-primary">Análisis Automático</p>
                  <p className="text-sm text-text-secondary">Analizar nuevos productos automáticamente</p>
                </div>
                <input type="checkbox" defaultChecked className="toggle-toggle" />
              </div>
            </div>
          </div>
        )}

        {/* Save Button */}
        <div className="flex justify-end pt-6 border-t border-border">
          <button
            onClick={handleSave}
            className={`btn-primary ${
              saved ? 'bg-success text-white' : ''
            }`}
          >
            <Save className="h-4 w-4 mr-2" />
            {saved ? 'Guardado!' : 'Guardar Cambios'}
          </button>
        </div>
      </motion.div>
    </div>
  )
}

export default Settings