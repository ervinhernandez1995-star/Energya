import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Mail, 
  MessageSquare, 
  Camera, 
  BarChart3, 
  Send, 
  Clock, 
  Target,
  Zap,
  Calendar,
  Users,
  TrendingUp,
  Plus,
  Settings,
  Play,
  Pause,
  Eye
} from 'lucide-react'

interface Campaign {
  id: string
  name: string
  type: 'email' | 'social' | 'push'
  status: 'active' | 'paused' | 'draft'
  reach: number
  engagement: number
  conversions: number
  roi: number
  scheduled: string
  platform: string
}

interface EmailTemplate {
  id: string
  name: string
  subject: string
  openRate: number
  clickRate: number
  lastUsed: string
}

const Marketing: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview')
  const [newCampaign, setNewCampaign] = useState(false)

  // Datos de campañas
  const campaigns: Campaign[] = [
    {
      id: '1',
      name: 'Promoción iPhone 15 - Black Friday',
      type: 'email',
      status: 'active',
      reach: 12500,
      engagement: 18.5,
      conversions: 245,
      roi: 340,
      scheduled: '2024-11-25',
      platform: 'Email'
    },
    {
      id: '2',
      name: 'Zapatillas Nike - Flash Sale',
      type: 'social',
      status: 'active',
      reach: 8500,
      engagement: 22.1,
      conversions: 189,
      roi: 280,
      scheduled: '2024-11-24',
      platform: 'Instagram'
    },
    {
      id: '3',
      name: 'MacBook Pro - Retargeting',
      type: 'push',
      status: 'paused',
      reach: 3200,
      engagement: 15.8,
      conversions: 67,
      roi: 195,
      scheduled: '2024-11-23',
      platform: 'Push'
    }
  ]

  // Templates de email
  const emailTemplates: EmailTemplate[] = [
    {
      id: '1',
      name: 'Bienvenida Nuevos Clientes',
      subject: '¡Bienvenido! 🎉 Tu primer descuento del 20% te espera',
      openRate: 32.5,
      clickRate: 8.7,
      lastUsed: '2024-11-20'
    },
    {
      id: '2',
      name: 'Carrito Abandonado',
      subject: '¡No olvides tu carrito! 🛒 10% de descuento adicional',
      openRate: 28.3,
      clickRate: 12.1,
      lastUsed: '2024-11-19'
    },
    {
      id: '3',
      name: 'Productos Trending',
      subject: '🔥 Los productos más populares esta semana',
      openRate: 25.8,
      clickRate: 6.4,
      lastUsed: '2024-11-18'
    }
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-success bg-success/10'
      case 'paused': return 'text-warning bg-warning/10'
      case 'draft': return 'text-text-secondary bg-gray-100'
      default: return 'text-text-secondary bg-gray-100'
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'email': return <Mail className="h-4 w-4" />
      case 'social': return <MessageSquare className="h-4 w-4" />
      case 'push': return <Zap className="h-4 w-4" />
      default: return <Target className="h-4 w-4" />
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-text-primary">Marketing Automatizado</h1>
          <p className="text-text-secondary mt-2">
            Crea y gestiona campañas de marketing inteligentes con IA
          </p>
        </div>
        <div className="mt-4 lg:mt-0 flex gap-3">
          <button className="btn-secondary">
            <Settings className="h-4 w-4 mr-2" />
            Configuración
          </button>
          <button 
            className="btn-primary"
            onClick={() => setNewCampaign(true)}
          >
            <Plus className="h-4 w-4 mr-2" />
            Nueva Campaña
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="card">
        <div className="flex space-x-1 bg-page-bg p-1 rounded-button">
          {[
            { id: 'overview', label: 'Resumen', icon: BarChart3 },
            { id: 'campaigns', label: 'Campañas', icon: Target },
            { id: 'templates', label: 'Templates', icon: Mail },
            { id: 'automation', label: 'Automatización', icon: Zap },
          ].map((tab) => {
            const Icon = tab.icon
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center px-4 py-2 rounded-button text-sm font-medium transition-all ${
                  activeTab === tab.id
                    ? 'bg-white text-primary-600 shadow-sm'
                    : 'text-text-secondary hover:text-text-primary'
                }`}
              >
                <Icon className="h-4 w-4 mr-2" />
                {tab.label}
              </button>
            )
          })}
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                title: 'CAMPAÑAS ACTIVAS',
                value: '8',
                change: '+2',
                icon: Target,
                color: 'text-success'
              },
              {
                title: 'EMAILS ENVIADOS',
                value: '24,567',
                change: '+12.5%',
                icon: Mail,
                color: 'text-primary-600'
              },
              {
                title: 'TASA APERTURA',
                value: '28.4%',
                change: '+3.2%',
                icon: Eye,
                color: 'text-warning'
              },
              {
                title: 'CONVERSIONES',
                value: '487',
                change: '+18.7%',
                icon: TrendingUp,
                color: 'text-success'
              }
            ].map((stat, index) => {
              const Icon = stat.icon
              return (
                <motion.div
                  key={stat.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="kpi-card"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-text-secondary uppercase">
                        {stat.title}
                      </p>
                      <p className="text-2xl font-bold text-text-primary mt-2">
                        {stat.value}
                      </p>
                      <p className="text-sm text-success mt-1">{stat.change}</p>
                    </div>
                    <Icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                </motion.div>
              )
            })}
          </div>

          {/* Recent Activity */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="card">
              <h3 className="text-lg font-semibold text-text-primary mb-4">
                Actividad Reciente
              </h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                  <div>
                    <p className="text-sm font-medium text-text-primary">
                      Campaña "iPhone 15" iniciada
                    </p>
                    <p className="text-xs text-text-secondary">Hace 2 horas</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-warning rounded-full"></div>
                  <div>
                    <p className="text-sm font-medium text-text-primary">
                      Email template "Carrito Abandonado" enviado
                    </p>
                    <p className="text-xs text-text-secondary">Hace 4 horas</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-primary-500 rounded-full"></div>
                  <div>
                    <p className="text-sm font-medium text-text-primary">
                      Nueva publicación programada en Instagram
                    </p>
                    <p className="text-xs text-text-secondary">Hace 6 horas</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="card">
              <h3 className="text-lg font-semibold text-text-primary mb-4">
                Próximas Tareas
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-warning/10 rounded-button">
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-warning" />
                    <span className="text-sm font-medium text-text-primary">
                      Flash Sale Nike - Programada
                    </span>
                  </div>
                  <span className="text-xs text-text-secondary">En 2 horas</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-primary-50 rounded-button">
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-primary-500" />
                    <span className="text-sm font-medium text-text-primary">
                      Newsletter semanal
                    </span>
                  </div>
                  <span className="text-xs text-text-secondary">Mañana 9:00 AM</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-success/10 rounded-button">
                  <div className="flex items-center space-x-2">
                    <Target className="h-4 w-4 text-success" />
                    <span className="text-sm font-medium text-text-primary">
                      Análisis de rendimiento
                    </span>
                  </div>
                  <span className="text-xs text-text-secondary">Domingo</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'campaigns' && (
        <div className="space-y-6">
          {/* Campaigns List */}
          <div className="space-y-4">
            {campaigns.map((campaign, index) => (
              <motion.div
                key={campaign.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="card"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="p-2 bg-primary-50 rounded-button">
                      {getTypeIcon(campaign.type)}
                    </div>
                    <div>
                      <h4 className="font-semibold text-text-primary">
                        {campaign.name}
                      </h4>
                      <div className="flex items-center space-x-4 text-sm text-text-secondary">
                        <span>{campaign.platform}</span>
                        <span>•</span>
                        <span>{campaign.reach.toLocaleString()} alcance</span>
                        <span>•</span>
                        <span>ROI: {campaign.roi}%</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(campaign.status)}`}>
                      {campaign.status}
                    </span>
                    <button className="btn-secondary p-2">
                      {campaign.status === 'active' ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                    </button>
                    <button className="btn-secondary p-2">
                      <Settings className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                <div className="mt-4 grid grid-cols-4 gap-4">
                  <div className="text-center">
                    <p className="text-lg font-bold text-text-primary">{campaign.engagement}%</p>
                    <p className="text-xs text-text-secondary">Engagement</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-bold text-text-primary">{campaign.conversions}</p>
                    <p className="text-xs text-text-secondary">Conversiones</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-bold text-text-primary">${(campaign.conversions * 35).toLocaleString()}</p>
                    <p className="text-xs text-text-secondary">Revenue</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-bold text-success">{campaign.roi}%</p>
                    <p className="text-xs text-text-secondary">ROI</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'templates' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold text-text-primary">
              Templates de Email
            </h2>
            <button className="btn-primary">
              <Plus className="h-4 w-4 mr-2" />
              Nuevo Template
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {emailTemplates.map((template, index) => (
              <motion.div
                key={template.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="card"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-semibold text-text-primary">
                      {template.name}
                    </h4>
                    <button className="btn-secondary p-1">
                      <Settings className="h-3 w-3" />
                    </button>
                  </div>
                  <p className="text-sm text-text-secondary">
                    "{template.subject}"
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <p className="text-xs text-text-secondary">Tasa Apertura</p>
                      <p className="font-bold text-primary-500">{template.openRate}%</p>
                    </div>
                    <div>
                      <p className="text-xs text-text-secondary">Click Rate</p>
                      <p className="font-bold text-success">{template.clickRate}%</p>
                    </div>
                  </div>
                  <p className="text-xs text-text-secondary">
                    Última vez: {template.lastUsed}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'automation' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="card">
              <h3 className="text-lg font-semibold text-text-primary mb-4">
                Reglas de Automatización
              </h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-success/10 rounded-button">
                  <div className="flex items-center space-x-2">
                    <Users className="h-4 w-4 text-success" />
                    <span className="text-sm font-medium text-text-primary">
                      Bienvenida nuevos clientes
                    </span>
                  </div>
                  <span className="text-xs bg-success text-white px-2 py-1 rounded-full">Activo</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-warning/10 rounded-button">
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-warning" />
                    <span className="text-sm font-medium text-text-primary">
                      Carrito abandonado (1h)
                    </span>
                  </div>
                  <span className="text-xs bg-warning text-white px-2 py-1 rounded-full">Activo</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-100 rounded-button">
                  <div className="flex items-center space-x-2">
                    <Target className="h-4 w-4 text-text-secondary" />
                    <span className="text-sm font-medium text-text-primary">
                      Post-compra (24h)
                    </span>
                  </div>
                  <span className="text-xs bg-gray-500 text-white px-2 py-1 rounded-full">Pausado</span>
                </div>
              </div>
            </div>

            <div className="card">
              <h3 className="text-lg font-semibold text-text-primary mb-4">
                Configurar Nueva Regla
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">
                    Disparador
                  </label>
                  <select className="input-field">
                    <option>Carrito abandonado</option>
                    <option>Compra completada</option>
                    <option>Cliente inactivo</option>
                    <option>Nuevo cliente</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">
                    Acción
                  </label>
                  <select className="input-field">
                    <option>Enviar email</option>
                    <option>Enviar push notification</option>
                    <option>Publicar en redes sociales</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">
                    Template
                  </label>
                  <select className="input-field">
                    <option>Carrito Abandonado</option>
                    <option>Bienvenida</option>
                    <option>Post-compra</option>
                  </select>
                </div>
                <button className="btn-primary w-full">
                  Crear Regla
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Marketing