import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Search, 
  Filter, 
  Star, 
  Heart, 
  Eye, 
  ShoppingCart, 
  TrendingUp,
  DollarSign,
  Package
} from 'lucide-react'

interface Product {
  id: string
  title: string
  price: number
  originalPrice: number
  image: string
  rating: number
  reviews: number
  score: number
  category: string
  supplier: string
  margin: number
  trending: boolean
  stock: number
}

const Products: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [sortBy, setSortBy] = useState('score')

  // Datos simulados de productos
  const products: Product[] = [
    {
      id: '1',
      title: 'iPhone 15 Pro Max 256GB',
      price: 899,
      originalPrice: 1199,
      image: 'https://via.placeholder.com/300x300/2563eb/white?text=iPhone+15',
      rating: 4.8,
      reviews: 1247,
      score: 94,
      category: 'Electrónicos',
      supplier: 'Amazon',
      margin: 25,
      trending: true,
      stock: 15
    },
    {
      id: '2',
      title: 'Zapatillas Nike Air Max 270',
      price: 89,
      originalPrice: 149,
      image: 'https://via.placeholder.com/300x300/16a34a/white?text=Nike+Shoes',
      rating: 4.6,
      reviews: 892,
      score: 88,
      category: 'Ropa',
      supplier: 'AliExpress',
      margin: 35,
      trending: true,
      stock: 32
    },
    {
      id: '3',
      title: 'MacBook Air M2 13" 256GB',
      price: 899,
      originalPrice: 1299,
      image: 'https://via.placeholder.com/300x300/6b7280/white?text=MacBook+Air',
      rating: 4.9,
      reviews: 567,
      score: 92,
      category: 'Electrónicos',
      supplier: 'Amazon',
      margin: 22,
      trending: false,
      stock: 8
    },
    {
      id: '4',
      title: 'Smartwatch Apple Watch Series 9',
      price: 299,
      originalPrice: 429,
      image: 'https://via.placeholder.com/300x300/f59e0b/white?text=Apple+Watch',
      rating: 4.7,
      reviews: 734,
      score: 86,
      category: 'Electrónicos',
      supplier: 'Mercado Libre',
      margin: 28,
      trending: true,
      stock: 23
    },
    {
      id: '5',
      title: 'Auriculares Sony WH-1000XM5',
      price: 199,
      originalPrice: 349,
      image: 'https://via.placeholder.com/300x300/dc2626/white?text=Sony+Audio',
      rating: 4.8,
      reviews: 445,
      score: 89,
      category: 'Electrónicos',
      supplier: 'AliExpress',
      margin: 32,
      trending: false,
      stock: 18
    },
    {
      id: '6',
      title: 'Camiseta Oversized Estampada',
      price: 19,
      originalPrice: 39,
      image: 'https://via.placeholder.com/300x300/8b5cf6/white?text=Oversized',
      rating: 4.3,
      reviews: 234,
      score: 75,
      category: 'Ropa',
      supplier: 'AliExpress',
      margin: 40,
      trending: true,
      stock: 67
    }
  ]

  const categories = ['all', 'Electrónicos', 'Ropa', 'Hogar', 'Deportes', 'Belleza']

  const filteredProducts = products
    .filter(product => {
      const matchesSearch = product.title.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory
      return matchesSearch && matchesCategory
    })
    .sort((a, b) => {
      if (sortBy === 'score') return b.score - a.score
      if (sortBy === 'price') return a.price - b.price
      if (sortBy === 'margin') return b.margin - a.margin
      return 0
    })

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-success'
    if (score >= 75) return 'text-warning'
    return 'text-error'
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-text-primary">Catálogo de Productos</h1>
          <p className="text-text-secondary mt-2">
            Productos analizados y optimizados con IA para maximizar ganancias
          </p>
        </div>
        <div className="mt-4 lg:mt-0">
          <button className="btn-primary">
            <Package className="h-5 w-5 mr-2" />
            Añadir Producto
          </button>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="card">
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Search */}
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-text-secondary" />
              <input
                type="text"
                placeholder="Buscar productos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input-field pl-10"
              />
            </div>
          </div>

          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="input-field lg:w-48"
          >
            {categories.map(category => (
              <option key={category} value={category}>
                {category === 'all' ? 'Todas las categorías' : category}
              </option>
            ))}
          </select>

          {/* Sort */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="input-field lg:w-48"
          >
            <option value="score">Mejor Score</option>
            <option value="price">Precio</option>
            <option value="margin">Mayor Margen</option>
          </select>
        </div>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredProducts.map((product, index) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="card group"
          >
            {/* Product Image */}
            <div className="relative overflow-hidden rounded-button mb-4">
              <img
                src={product.image}
                alt={product.title}
                className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              {product.trending && (
                <div className="absolute top-2 left-2 bg-success text-white px-2 py-1 rounded-full text-xs font-medium">
                  <TrendingUp className="h-3 w-3 inline mr-1" />
                  Trending
                </div>
              )}
              <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full">
                <span className={`text-sm font-bold ${getScoreColor(product.score)}`}>
                  {product.score}
                </span>
              </div>
            </div>

            {/* Product Info */}
            <div className="space-y-3">
              <div>
                <h3 className="font-semibold text-text-primary line-clamp-2">
                  {product.title}
                </h3>
                <div className="flex items-center mt-1">
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="text-sm text-text-secondary ml-1">
                      {product.rating} ({product.reviews})
                    </span>
                  </div>
                  <span className="text-xs text-text-secondary ml-2">
                    {product.supplier}
                  </span>
                </div>
              </div>

              {/* Pricing */}
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-lg font-bold text-text-primary">
                    ${product.price}
                  </span>
                  <span className="text-sm text-text-secondary line-through ml-2">
                    ${product.originalPrice}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-xs text-text-secondary">Margen</span>
                  <div className="flex items-center">
                    <DollarSign className="h-3 w-3 text-success" />
                    <span className="text-sm font-medium text-success">
                      {product.margin}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Stock */}
              <div className="flex items-center justify-between text-sm">
                <span className="text-text-secondary">
                  Stock: {product.stock} unidades
                </span>
                <span className="text-xs bg-primary-100 text-primary-700 px-2 py-1 rounded-full">
                  {product.category}
                </span>
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-2">
                <button className="flex-1 btn-primary">
                  <ShoppingCart className="h-4 w-4 mr-1" />
                  Publicar
                </button>
                <button className="btn-secondary p-3">
                  <Eye className="h-4 w-4" />
                </button>
                <button className="btn-secondary p-3">
                  <Heart className="h-4 w-4" />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* No Results */}
      {filteredProducts.length === 0 && (
        <div className="text-center py-12">
          <Package className="h-12 w-12 text-text-secondary mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-text-primary mb-2">
            No se encontraron productos
          </h3>
          <p className="text-text-secondary">
            Intenta ajustar los filtros o términos de búsqueda
          </p>
        </div>
      )}
    </div>
  )
}

export default Products