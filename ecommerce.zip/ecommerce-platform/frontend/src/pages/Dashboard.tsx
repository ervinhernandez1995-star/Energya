import React from 'react'
import { motion } from 'framer-motion'
import { DollarSign, TrendingUp, Package, Users, ShoppingCart, AlertCircle } from 'lucide-react'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  BarElement,
} from 'chart.js'
import { Line, Doughnut, Bar } from 'react-chartjs-2'

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  BarElement
)

const Dashboard: React.FC = () => {
  // Datos simulados para los gráficos
  const weeklyRevenueData = {
    labels: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'],
    datasets: [
      {
        label: 'Ganancia Diaria ($)',
        data: [120, 190, 300, 280, 220, 350, 420],
        borderColor: 'rgb(37, 99, 235)',
        backgroundColor: 'rgba(37, 99, 235, 0.1)',
        tension: 0.4,
        fill: true,
      },
    ],
  }

  const categoryData = {
    labels: ['Electrónicos', 'Ropa', 'Hogar', 'Deportes', 'Belleza'],
    datasets: [
      {
        data: [35, 25, 20, 12, 8],
        backgroundColor: [
          '#2563eb',
          '#16a34a',
          '#f59e0b',
          '#dc2626',
          '#8b5cf6',
        ],
        borderWidth: 0,
      },
    ],
  }

  const topProductsData = {
    labels: ['iPhone 15', 'Zapatillas Nike', 'Laptop Dell', 'Auriculares Sony', 'Smartwatch'],
    datasets: [
      {
        label: 'Unidades Vendidas',
        data: [45, 38, 32, 28, 24],
        backgroundColor: 'rgba(37, 99, 235, 0.8)',
      },
    ],
  }

  const kpiCards = [
    {
      title: 'GANANCIA NETA',
      value: '$2,847',
      change: '+12.5%',
      trend: 'up',
      icon: DollarSign,
      color: 'text-success',
    },
    {
      title: 'VENTAS HOY',
      value: '24',
      change: '+8.2%',
      trend: 'up',
      icon: ShoppingCart,
      color: 'text-primary-600',
    },
    {
      title: 'PRODUCTOS ACTIVOS',
      value: '156',
      change: '+3.1%',
      trend: 'up',
      icon: Package,
      color: 'text-warning',
    },
    {
      title: 'VISITAS ÚNICAS',
      value: '1,247',
      change: '-2.3%',
      trend: 'down',
      icon: Users,
      color: 'text-error',
    },
  ]

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  }

  return (
    <div className="space-y-6">
      {/* KPIs Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiCards.map((kpi, index) => {
          const Icon = kpi.icon
          return (
            <motion.div
              key={kpi.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="kpi-card"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-text-secondary uppercase">
                    {kpi.title}
                  </p>
                  <p className="text-3xl font-bold text-text-primary mt-2">
                    {kpi.value}
                  </p>
                  <div className="flex items-center mt-2">
                    <span className={`text-sm font-medium ${
                      kpi.trend === 'up' ? 'text-success' : 'text-error'
                    }`}>
                      {kpi.change}
                    </span>
                    <span className="text-sm text-text-secondary ml-2">
                      vs ayer
                    </span>
                  </div>
                </div>
                <Icon className={`h-8 w-8 ${kpi.color}`} />
              </div>
            </motion.div>
          )
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Revenue Chart */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="card"
        >
          <h3 className="text-lg font-semibold text-text-primary mb-4">
            Ganancia Semanal
          </h3>
          <div className="h-80">
            <Line data={weeklyRevenueData} options={chartOptions} />
          </div>
        </motion.div>

        {/* Categories Chart */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="card"
        >
          <h3 className="text-lg font-semibold text-text-primary mb-4">
            Ventas por Categoría
          </h3>
          <div className="h-80">
            <Doughnut 
              data={categoryData} 
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    position: 'bottom' as const,
                  },
                },
              }} 
            />
          </div>
        </motion.div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top Products */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="lg:col-span-2 card"
        >
          <h3 className="text-lg font-semibold text-text-primary mb-4">
            Productos Más Vendidos
          </h3>
          <div className="h-64">
            <Bar data={topProductsData} options={chartOptions} />
          </div>
        </motion.div>

        {/* Alerts & Activity */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="card"
        >
          <h3 className="text-lg font-semibold text-text-primary mb-4">
            Actividad Reciente
          </h3>
          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <AlertCircle className="h-5 w-5 text-warning mt-1" />
              <div>
                <p className="text-sm font-medium text-text-primary">
                  Stock Bajo
                </p>
                <p className="text-xs text-text-secondary">
                  3 productos con menos de 5 unidades
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <TrendingUp className="h-5 w-5 text-success mt-1" />
              <div>
                <p className="text-sm font-medium text-text-primary">
                  Nicho Detectado
                </p>
                <p className="text-xs text-text-secondary">
                  "Productos para mascotas" trending
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <ShoppingCart className="h-5 w-5 text-primary-500 mt-1" />
              <div>
                <p className="text-sm font-medium text-text-primary">
                  Nueva Venta
                </p>
                <p className="text-xs text-text-secondary">
                  iPhone 15 - $847 ganancia
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}

export default Dashboard