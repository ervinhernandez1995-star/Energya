# 🚀 Guía Completa de Instalación - Plataforma E-commerce Automatizada

## 📋 Índice
1. [Requisitos Previos](#requisitos-previos)
2. [Instalación del Frontend](#instalación-del-frontend)
3. [Instalación del Backend](#instalación-del-backend)
4. [Configuración de Base de Datos](#configuración-de-base-de-datos)
5. [Configuración de APIs](#configuración-de-apis)
6. [Configuración de Pagos](#configuración-de-pagos)
7. [Deployment](#deployment)
8. [Configuración de Automatización](#configuración-de-automatización)
9. [Mantenimiento](#mantenimiento)

---

## 📋 Requisitos Previos

### Software Necesario
- **Node.js** 16+ ([Descargar](https://nodejs.org/))
- **Git** ([Descargar](https://git-scm.com/))
- **Visual Studio Code** (recomendado) ([Descargar](https://code.visualstudio.com/))

### Cuentas Necesarias
- **Supabase** (Base de datos gratuita) - [Crear cuenta](https://supabase.com)
- **OpenAI** (API de IA) - [Crear cuenta](https://openai.com)
- **Stripe** (Procesamiento de pagos) - [Crear cuenta](https://stripe.com)
- **PayPal** (Método de pago alternativo) - [Crear cuenta](https://paypal.com)
- **Vercel** o **Netlify** (Deployment frontend) - [Crear cuenta](https://vercel.com)

---

## 🌐 Instalación del Frontend

### 1. Clonar el Repositorio
```bash
git clone https://github.com/tu-usuario/ecommerce-platform.git
cd ecommerce-platform
```

### 2. Instalar Dependencias
```bash
cd frontend
npm install
```

### 3. Configurar Variables de Entorno
Crea un archivo `.env.local` en la carpeta `frontend`:

```env
# Backend API URL
VITE_API_URL=http://localhost:5000

# Tu dominio cuando hagas deployment
VITE_API_URL_PROD=https://tu-backend.vercel.app

# Google Analytics (opcional)
VITE_GA_TRACKING_ID=

# Configuración de modo desarrollo
NODE_ENV=development
```

### 4. Ejecutar en Desarrollo
```bash
npm run dev
```

El frontend estará disponible en `http://localhost:3000`

### 5. Build para Producción
```bash
npm run build
```

---

## ⚙️ Instalación del Backend

### 1. Instalar Dependencias
```bash
cd backend
npm install
```

### 2. Configurar Variables de Entorno
Crea un archivo `.env` en la carpeta `backend`:

```env
# === CONFIGURACIÓN BÁSICA ===
NODE_ENV=development
PORT=5000
JWT_SECRET=tu_jwt_secret_muy_seguro_aqui

# === BASE DE DATOS ===
# Usar Supabase (recomendado)
SUPABASE_URL=https://tu-proyecto.supabase.co
SUPABASE_KEY=tu_supabase_service_role_key

# === APIs DE IA ===
OPENAI_API_KEY=tu_openai_api_key_aqui

# === GOOGLE TRENDS (OPCIONAL) ===
GOOGLE_TRENDS_API_KEY=tu_google_trends_key

# === PAYMENTS ===
# Stripe
STRIPE_SECRET_KEY=sk_test_tu_stripe_secret_key
STRIPE_PUBLISHABLE_KEY=pk_test_tu_stripe_public_key
STRIPE_WEBHOOK_SECRET=whsec_tu_webhook_secret

# PayPal
PAYPAL_CLIENT_ID=tu_paypal_client_id
PAYPAL_CLIENT_SECRET=tu_paypal_client_secret
PAYPAL_MODE=sandbox  # cambiar a 'live' para producción

# === EMAIL SERVICE ===
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=tu_email@gmail.com
SMTP_PASS=tu_app_password

# === FRONTEND URL ===
FRONTEND_URL=http://localhost:3000

# === CONFIGURACIÓN DE DROPSHIPPING ===
DEFAULT_PROFIT_MARGIN=25
AUTO_PAYOUT_THRESHOLD=100
```

---

## 🗄️ Configuración de Base de Datos

### Opción 1: Supabase (Recomendado - Gratuito)

#### 1. Crear Proyecto en Supabase
1. Ve a [supabase.com](https://supabase.com) y crea una cuenta
2. Crea un nuevo proyecto
3. Espera a que se configure (puede tomar 2-3 minutos)

#### 2. Obtener Credenciales
1. Ve a Settings → API
2. Copia la URL del proyecto y Service Role Key
3. Pégalas en tu archivo `.env` del backend

#### 3. Ejecutar Setup de Base de Datos
```bash
cd backend
npm run setup-db
```

Este comando creará automáticamente todas las tablas necesarias.

#### 4. Verificar Configuración
1. Ve a Table Editor en Supabase
2. Deberías ver las tablas: `users`, `products`, `orders`, `analytics`, etc.
3. Si no aparecen, ejecuta manualmente:
```sql
-- Ejecuta esto en el SQL Editor de Supabase
CREATE TABLE IF NOT EXISTS products (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title VARCHAR(500) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### Opción 2: SQLite (Desarrollo Local)

Si prefieres usar SQLite para desarrollo:
1. Cambia las credenciales de Supabase en `.env`
2. El sistema usará automáticamente SQLite como fallback

---

## 🔑 Configuración de APIs

### 1. OpenAI API (Esencial para IA)

#### Crear Cuenta
1. Ve a [openai.com](https://openai.com) y crea cuenta
2. Ve a API Keys
3. Crea una nueva API key
4. Copia la key y pégala en `OPENAI_API_KEY`

#### Verificar Funcionamiento
```bash
# Test en el backend
curl -X POST http://localhost:5000/api/products/analyze \
  -H "Content-Type: application/json" \
  -d '{"title": "iPhone 15", "price": 899}'
```

### 2. Google Trends API (Opcional)

Para análisis de tendencias:
1. Ve a [Google Cloud Console](https://console.cloud.google.com)
2. Crea un proyecto
3. Habilita Google Trends API
4. Crea credenciales (API Key)
5. Pégala en `GOOGLE_TRENDS_API_KEY`

### 3. APIs de Proveedores (Futuro)

Para dropshipping automático, necesitarás:
- **Amazon Product Advertising API**
- **AliExpress API** 
- **MercadoLibre API**

Por ahora, el sistema funciona con scraping ético y APIs públicas.

---

## 💳 Configuración de Pagos

### 1. Stripe (Recomendado)

#### Crear Cuenta
1. Ve a [stripe.com](https://stripe.com) y crea cuenta
2. Ve a Developers → API Keys
3. Copia Test Secret Key
4. Pégala en `STRIPE_SECRET_KEY`

#### Configurar Webhooks
1. Ve a Developers → Webhooks
2. Añade endpoint: `https://tu-backend.vercel.app/webhooks/stripe`
3. Selecciona eventos: `payment_intent.succeeded`, `charge.succeeded`
4. Copia Webhook Secret y pégala en `STRIPE_WEBHOOK_SECRET`

#### Conectar Cuenta Bancaria
1. Ve a Settings → Bank accounts
2. Añade tu cuenta de débito
3. Verifica la cuenta
4. En producción, Stripe enviará automáticamente las ganancias

### 2. PayPal

#### Crear App en PayPal
1. Ve a [developer.paypal.com](https://developer.paypal.com)
2. Crea una app
3. Copia Client ID y Client Secret
4. Pégalas en `PAYPAL_CLIENT_ID` y `PAYPAL_CLIENT_SECRET`
5. Cambia `PAYPAL_MODE` a `live` para producción

#### Configurar Retiros
1. Ve a tu cuenta PayPal
2. Añade tu tarjeta de débito
3. Activa "Retirar a tarjeta" en Configuración
4. Los retiros se harán automáticamente

---

## 🚀 Deployment

### Frontend en Vercel

#### 1. Instalar Vercel CLI
```bash
npm i -g vercel
```

#### 2. Deploy
```bash
cd frontend
vercel --prod
```

#### 3. Configurar Variables en Vercel
1. Ve al dashboard de Vercel
2. Ve a tu proyecto → Settings → Environment Variables
3. Añade:
   - `VITE_API_URL`: Tu backend URL
   - `VITE_GA_TRACKING_ID`: Tu Google Analytics ID

### Backend en Railway (Recomendado)

#### 1. Instalar Railway CLI
```bash
npm install -g @railway/cli
```

#### 2. Deploy
```bash
cd backend
railway login
railway init
railway add
```

#### 3. Configurar Variables
```bash
railway variables set NODE_ENV=production
railway variables set PORT=5000
# Añade todas las variables de .env
```

#### 4. Deploy
```bash
railway up
```

### Alternativa: Render

#### 1. Conectar GitHub
1. Ve a [render.com](https://render.com)
2. Conecta tu repositorio
3. Selecciona el proyecto backend

#### 2. Configurar Build
- **Build Command**: `npm install`
- **Start Command**: `npm start`

#### 3. Configurar Variables
Añade todas las variables de `.env` en las settings del servicio.

---

## 🤖 Configuración de Automatización

### 1. Cron Jobs (Incluidos automáticamente)

El sistema incluye automatizaciones que se ejecutan:

- **2:00 AM**: Análisis de productos trending
- **Cada 5 min**: Procesamiento de órdenes (8 AM - 10 PM)
- **Cada hora**: Marketing automatizado
- **6:00 AM**: Generación de reportes
- **Domingos 3:00 AM**: Análisis semanal de tendencias

### 2. Verificar Automatización

Una vez deployado, el sistema iniciará automáticamente todos los jobs.
Puedes verificar que funcionan revisando los logs:

#### En Railway:
```bash
railway logs
```

#### En desarrollo local:
Los logs aparecerán en la consola donde ejecutes el backend.

### 3. Manual Triggers (Para Testing)

Si quieres probar funciones específicas:

```bash
# Analizar productos trending
curl -X POST http://localhost:5000/api/automation/daily-analysis

# Procesar órdenes pendientes
curl -X POST http://localhost:5000/api/automation/process-orders

# Enviar campañas de marketing
curl -X POST http://localhost:5000/api/automation/marketing
```

---

## 🔧 Mantenimiento

### 1. Monitoreo de Logs

#### Errores del Sistema
- Revisa los logs del backend regularmente
- Los errores aparecerán como `❌ Error: ...`
- Los logs exitosos aparecerán como `✅ Success: ...`

#### Performance
- El backend registra el tiempo de respuesta de cada API
- Si notas lentitud, revisa la base de datos y APIs externas

### 2. Backup de Datos

#### Supabase (Automático)
- Supabase hace backup automático
- También puedes hacer backup manual desde el dashboard

#### Configuraciones
- Mantén respaldos de tus variables de entorno
- Documenta cualquier cambio en APIs o configuraciones

### 3. Actualizaciones

#### Dependencias
```bash
# Actualizar frontend
cd frontend && npm update

# Actualizar backend  
cd backend && npm update
```

#### Sistema
- Mantén el sistema actualizado siguiendo las mejores prácticas de seguridad
- Revisa las APIs externas por cambios en sus términos de servicio

### 4. Optimización

#### Base de Datos
- Supabase maneja automáticamente el scaling
- Monitorea el uso en el dashboard

#### API Calls
- Las APIs externas tienen límites de rate
- El sistema incluye delays inteligentes para evitar límites

---

## ✅ Lista de Verificación Final

### Antes de Ir a Producción

- [ ] ✅ Todas las APIs configuradas y funcionando
- [ ] ✅ Base de datos configurada y tablas creadas
- [ ] ✅ Pagos de Stripe/PayPal configurados
- [ ] ✅ Frontend y backend deployados
- [ ] ✅ Dominios configurados correctamente
- [ ] ✅ Variables de entorno en producción
- [ ] ✅ Webhooks configurados
- [ ] ✅ Automatizaciones funcionando
- [ ] ✅ Test de orden completa realizado
- [ ] ✅ Backup de configuraciones realizado

### Test de Funcionamiento Completo

1. **Crear producto de prueba**
   - Usa la interfaz de análisis de productos
   - Verifica que el scoring funciona

2. **Probar flujo de compra**
   - Añade producto al carrito
   - Completa el checkout
   - Verifica procesamiento de orden

3. **Verificar automatizaciones**
   - Revisa logs del scheduler
   - Confirma que se ejecutan las tareas programadas

4. **Test de pagos**
   - Usa tarjetas de prueba de Stripe
   - Verifica que se procesan correctamente
   - Confirma que se calcula la ganancia

---

## 🆘 Solución de Problemas Comunes

### Error: "Cannot connect to database"
- Verifica las credenciales de Supabase
- Confirma que el proyecto esté activo
- Revisa que las tablas estén creadas

### Error: "OpenAI API rate limit"
- Verifica tu API key de OpenAI
- Considera hacer upgrade del plan
- El sistema maneja automáticamente los delays

### Error: "Stripe webhook failed"
- Confirma que la URL del webhook sea correcta
- Verifica que el webhook secret coincida
- Revisa los logs de Stripe para más detalles

### Frontend no conecta al backend
- Verifica `VITE_API_URL` en el frontend
- Confirma que el backend esté ejecutándose
- Revisa CORS settings

### Automatizaciones no funcionan
- El scheduler se ejecuta en el backend deployado
- En desarrollo local funciona automáticamente
- Revisa que las cron expressions estén correctas

---

## 📞 Soporte

Si necesitas ayuda:

1. **Revisa esta documentación completa**
2. **Consulta los logs del sistema**
3. **Abre un issue en GitHub** con:
   - Descripción del problema
   - Logs relevantes
   - Configuración del entorno
   - Pasos para reproducir el error

¡Tu plataforma e-commerce automatizada está lista para generar ingresos! 🚀